<template>
  <div class="layout">
    <Header></Header>

    <div class="main">
      <Aside></Aside>

      <keep-alive>
        <router-view class="content" />
      </keep-alive>
    </div>
  </div>
</template>

<script>
import Header from './webComponents/Header.vue'
import Aside from './webComponents/Aside.vue'
export default {
  components: {
    Header,
    Aside
  }
}
</script>

<style lang="scss" scoped>
.layout {
  height: 100%;
  // border: 1px solid red;
  display: flex;
  flex-direction: column;

  .main {
    flex: 1;
    // background: gray;

    display: flex;

    .content {
      flex: 1;
    }
  }
}
</style>
