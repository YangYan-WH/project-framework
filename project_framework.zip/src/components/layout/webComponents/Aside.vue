<template>
  <div class="layout-aside">
    <el-menu default-active="/overview" :router="true" @open="handleOpen" @close="handleClose">
      <div v-for="(itemTop, i) in getSideBarByRoutes()" :key="i">
        <!-- 存在二级菜单 -->
        <el-submenu v-if="itemTop.children" :index="itemTop.path">
          <template slot="title">
            <span>{{ itemTop.title || itemTop.name }}</span>
          </template>
          <el-menu-item-group>
            <el-menu-item v-for="(item2nd, j) in itemTop.children" :key="j" :index="item2nd.path">
              <span>{{ item2nd.title || item2nd.name }}</span>
            </el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <!-- 不存在二级菜单 -->
        <el-menu-item v-else :index="itemTop.path">
          <span slot="title">{{ itemTop.title || itemTop.name }}</span>
        </el-menu-item>
      </div>
    </el-menu>

    <!--
    <el-menu default-active="2" @open="handleOpen" @close="handleClose">
      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span>导航一</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="1-1">选项1</el-menu-item>
          <el-menu-item index="1-2">选项2</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-menu-item index="2">
        <i class="el-icon-menu"></i>
        <span slot="title">导航二</span>
      </el-menu-item>
      <el-menu-item index="3" disabled>
        <i class="el-icon-document"></i>
        <span slot="title">导航三</span>
      </el-menu-item>
      <el-menu-item index="4">
        <i class="el-icon-setting"></i>
        <span slot="title">导航四</span>
      </el-menu-item>
    </el-menu> -->
  </div>
</template>

<script>
import { routes } from '@/router/routes'

export default {
  data() {
    return {}
  },
  mounted() {
    this.getSideBarByRoutes()
  },
  methods: {
    /**
     * @description 展开指定的 sub-menu
     */
    handleOpen(key, keyPath) {
      console.log(key, keyPath)
    },
    /**
     * @description 收起指定的 sub-menu
     */
    handleClose(key, keyPath) {
      console.log(key, keyPath)
    },
    /**
     * @description 根据routes获取导航栏
     */
    getSideBarByRoutes() {
      let result = []
      for (let i = 0; i < routes.length; i++) {
        result[i] = {
          path: routes[i].path,
          name: routes[i].name,
          title: routes[i].meta?.title
        }
        if (routes[i].children) {
          result[i].children = []
          for (let j = 0; j < routes[i].children.length; j++) {
            result[i].children[j] = {
              path: routes[i].children[j].path,
              name: routes[i].children[j].name,
              title: routes[i].children[j].meta?.title
            }
          }
        }
      }
      console.log('result', result)
      return result
    }
  }
}
</script>

<style lang="scss" scoped>
.layout-aside {
  // background: pink;
  ::v-deep .el-menu {
    border-right: none;
  }
  // width: 200px;
  width: vw(200);
}
</style>
