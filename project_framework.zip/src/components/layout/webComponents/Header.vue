<template>
  <div class="header">
    <span>logo</span>
    <span>顶栏</span>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
.header {
  border: 1px solid green;
  // height: 60px;
  height: vh(60);
}
</style>
