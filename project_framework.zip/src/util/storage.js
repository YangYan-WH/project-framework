const keyName = 'general-education-'

/**
 * @description 将值放入storage
 * @param {key} 为存入的名字
 * @param {content} 为存入的内容
 * @param {type} 为存入的类型, 如果type的值为 session, 表示存入sessionStorage, 否则默认为 localStorage
 */
export const setStorage = ({ key, content, type } = {}) => {
  key = keyName + key

  let obj = {
    content: content,
    type,
    datetime: new Date().getTime()
  }
  if (type === 'session') {
    window.sessionStorage.setItem(key, JSON.stringify(obj))
  } else {
    window.localStorage.setItem(key, JSON.stringify(obj))
  }
}

/**
 * @description 将值从storage中取出
 * @param {key} 为存入的名字
 * @param {type} 为存入的类型, 如果type的值为 session, 表示存入sessionStorage, 否则默认为 localStorage
 */
export const getStorage = ({ key, type } = {}) => {
  key = keyName + key
  let obj = {}
  if (type === 'session') {
    window.sessionStorage.getItem(key)
  } else {
    window.localStorage.getItem(key)
  }
  return obj.content
}

/**
 * @description 将值从storage中删除
 * @param {key} 为存入的名字
 * @param {type} 为存入的类型, 如果type的值为 session, 表示存入sessionStorage, 否则默认为 localStorage
 */
export const removeStorage = ({ key, type } = {}) => {
  key = keyName + key

  if (type === 'session') {
    window.sessionStorage.removeItem(key)
  } else {
    window.localStorage.removeItem(key)
  }
}

/**
 * @description 清空storage
 * @param {type} 为存入的类型, 如果type的值为 session, 表示存入sessionStorage, 否则默认为 localStorage
 */
export const emptyStorage = ({ type } = {}) => {
  if (type === 'session') {
    window.sessionStorage.clear()
  } else {
    window.localStorage.clear()
  }
}
