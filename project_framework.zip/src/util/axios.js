import store from '@/store'
import router from '@/router'
import axios from 'axios'
import { Message } from 'element-ui'

const service = axios.create({
  baseURL: '',
  timeout: 0
})

/**
 * 请求拦截
 */
service.interceptors.request.use(
  config => {
    //一般写入修改请求头
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

/**
 * 响应拦截
 */
service.interceptors.response.use(
  response => {
    //写http请求成功后, 与后端约定的code的逻辑
    let code
    if (code === 200) {
      return response
    } else {
      let error
      Message({
        type: 'error',
        message: error
      })
      return Promise.reject(error)
    }
  },
  error => {
    //写 http 请求 > 300 后的逻辑

    if (process.env.NODE_ENV === 'development') {
      console.log(error)
    }
    Message({
      type: 'error',
      message: error
    })

    return Promise.reject(error)
  }
)

service.all = axios.all
service.spread = axios.spread
export default service
