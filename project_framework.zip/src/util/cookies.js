import Cookies from 'js-cookies'

const keyName = 'general-education-'

/**
 * @description 从cookies取值
 * @params {key} 存入的key值
 * @returns 获取cookies中对应key值得内容
 */
export const getCookies = ({ key }) => {
  key = keyName + key
  return Cookies.get(key)
}

/**
 * @description 将值存入存入cookies
 * @params {key} 存入的key值
 * @params {content} 存入的内容
 */
export const setCookies = ({ key, content }) => {
  key = keyName + key
  return Cookies.set(key, content)
}

/**
 * @description 将值存入存入cookies
 * @params {key} 存入的key值
 */
export const removeCookies = ({ key }) => {
  key = keyName + key
  return Cookies.remove(key)
}
