// import Home from '../views/Home.vue'
import Layout from '@/components/layout/Layout'

export const routes = [
  {
    path: '/',
    component: Layout,
    redirect: '/overview',
    meta: {
      title: '概况'
    },
    children: [
      {
        path: '/overview',
        name: 'index',
        component: () => import('@/views/home/Home'),
        meta: {
          title: '学生概况'
        }
      },
      {
        path: '/test',
        name: 'test',
        component: () => import('@/views/home/Test'),
        meta: {
          title: '教职工概况'
        }
      }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/login/Login')
  }
]
