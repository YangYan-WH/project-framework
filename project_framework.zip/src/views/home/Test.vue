<template>
  <div>教职工概况</div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
