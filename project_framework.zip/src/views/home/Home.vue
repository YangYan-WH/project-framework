<template>
  <div>学生概况</div>
</template>

<script>
export default {
  // name: 'Home',
  components: {}
}
</script>
