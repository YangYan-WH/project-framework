const path = require('path')
let resolve = dir => path.join(__dirname, dir)

module.exports = {
  lintOnSave: false,

  //部署应用包时的基本url
  publicPath: './',
  //build 打包输出文件目录
  outputDir: 'dist',
  //放置静态文件目录
  assetsDir: 'assets',
  //生产环境是否使用 sourceMap 文件
  productionSourceMap: false,
  //webpack 相关配置
  chainWebpack: config => {
    //scss 全局使用
    const oneOfsMap = config.module.rule('scss').oneOfs.store
    oneOfsMap.forEach( item => {
      item.use('sass-resources-loader')
          .loader('sass-resources-loader')
          .options({
            resources: ['src/assets/css/common.scss']
            // resources: ['src/assets/css/global.scss']
          })
          .end()
    })
    //css 热更新
    config.resolve.symlinks(true)
    //修改别名
    config.resolve.alias.set('@', resolve('src'))

    //设置 svg-sprite-loader
    config.module
      .rule('svg')
      .exclude.add(resolve('src/assets/svgIcon'))
      .end()
    config.module
      .rule('icons')
      .test(/\.svg$/)
      .include.add(resolve('src/assets/svgIcon'))
      .end()
      .use('svg-sprite-loader')
      .loader('svg-sprite-loader')
      .options({
        symbolId: 'icon-[name]'
      })
  },
  devServer: {
    proxy: {
      '/api': {
        target: 'localhost:8080',
        changeOrigin: true
      }
    }
  }
}
